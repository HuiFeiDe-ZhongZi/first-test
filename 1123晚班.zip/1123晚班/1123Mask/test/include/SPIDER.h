#include<SOCKET.h>



typedef struct
{
	char origin_url[4096];
	char domain[1024];
	char path[1024];
	char fileName[1024];
	char IP[16];
	int PORT;
	int HTYPE; // 0 http 1 https
}url_t;



int spider_net_init(); // 网络初始化

int spider_analyse_url(url_t *); // 传入只附带原始地址的url_t,传出解析后的

int spider_connect_webserver(int,url_t); // 完成tcp链接

int spider_create_request(char *,url_t); // 创建请求头

int spider_request_response(int webfd,char * request_head,url_t node); // 请求与响应

int spider_get_statuscode(const char *); // 成功返回获取的响应码
