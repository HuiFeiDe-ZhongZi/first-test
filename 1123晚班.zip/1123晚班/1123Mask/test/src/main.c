#include<SPIDER.h>


//http://img.pconline.com.cn/images/upload/upc/tx/photoblog/1811/23/c5/120664311_1542959809703_mthumb.jpg

int main()
{
	int webfd;
	char request_head[4096];
	url_t node;

	const char * src = "http://img.pconline.com.cn/images/upload/upc/tx/photoblog/1811/23/c5/120664311_1542959809703_mthumb.jpg"; 

	webfd = spider_net_init();
	strcpy(node.origin_url,src);

	spider_analyse_url(&node);

	spider_connect_webserver(webfd,node);

	spider_create_request(request_head,node);

	spider_request_response(webfd,request_head,node); 
	return 0;
}
	
