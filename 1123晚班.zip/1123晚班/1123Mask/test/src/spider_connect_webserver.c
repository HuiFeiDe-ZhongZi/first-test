#include<SPIDER.h>


int spider_connect_webserver(int sockfd,url_t node)
{
	struct sockaddr_in webserver;
	bzero(&webserver,sizeof(webserver));
	webserver.sin_family = AF_INET;
	webserver.sin_port = htons(node.PORT);
	inet_pton(AF_INET,node.IP,&webserver.sin_addr.s_addr);
	if((CONNECT(sockfd,(struct sockaddr*)&webserver,sizeof(webserver))) == 0)
	{
		printf("[3] 连接 [%s] web服务器成功...\n",node.domain);
	}

	return 0;
}


