#include<iostream>
#include<deque>
#include<algorithm>
using namespace std;


int main()
{
	deque<int> a;
	a.push_back(3);
	a.push_back(4);
	a.push_front(2);
	a.push_front(1);


	a.pop_front();
	a.pop_back();

	deque<int>::iterator ite = a.begin();
	for(ite;ite!=a.end();ite++)
	{
		cout<<*ite<<" ";
	}
	cout << endl;

	for(int i:a)
	{
		cout << i << " ";
	}
	cout<<endl;

	return 0;
}

