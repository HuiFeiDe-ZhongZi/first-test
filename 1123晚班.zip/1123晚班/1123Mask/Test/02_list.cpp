#include<iostream>
#include<list>
#include<algorithm>
using namespace std;

void show(int a)
{
	cout<<a<<" ";
}

int main()
{
	list<int> lst1;
	lst1.push_back(3);
	lst1.push_back(3);
	lst1.push_back(1);
	lst1.push_back(1);
	lst1.push_back(2);
	lst1.push_back(3);
	lst1.push_back(4);
	lst1.push_back(3);

	list<int> lst2;
	lst2.push_back(4);
	lst2.push_back(6);
	lst2.push_back(9);
	lst2.push_back(1);
	lst2.push_back(0);
	lst2.push_back(5);

	::for_each(lst1.begin(),lst1.end(),&show);
	cout<<endl;

	//lst1.remove(3); // 将数值为3的所有元素移除
	//lst1.unique(); //删除连续相同的 只剩一个

	list<int>::iterator ite = ::find(lst1.begin(),lst1.end(),1);
	list<int>::iterator iteFirst = ::find(lst2.begin(),lst2.end(),6);
	list<int>::iterator iteLast = ::find(lst2.begin(),lst2.end(),1);

	//lst1.splice(ite,lst2);  // 链表插入指定位置 参数1 位置 参数2 新链表
	//lst1.splice(ite,lst2,iteFirst); // 在lst1这个链表的ite位置,插入lst2这个链表的iteFirst标记的一个元素
	//lst1.splice(ite,lst2,iteFirst,iteLast); // 在lst1这个链表的ite位置,插入lst2这个链表的iteFirst到iteLast这一段


	lst1.sort();
	lst2.sort();
	lst1.merge(lst2); // 使用merge合并之前必须排序 否则无法输出

	::for_each(lst1.begin(),lst1.end(),&show);
	cout<<endl;

	
	return 0;
}
