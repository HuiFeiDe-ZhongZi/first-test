#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;


//vector 使用尽量避免插入 删除

void show(int a)
{
	cout<<a <<" ";
}

int main()
{
	vector<int> vec;
	//vector<int> vec[10]; //10个数组
	//vector<int> vec(10); //一个数组10个元素 
	
	//1.迭代器打印
	//vectot<int>::iterator ite = vec.begin();
	//while(ite!=vec.end())
	//{
	//	cout<<*ite<<" ";
	//	++ite;
	//}
	
	//2.数组下标打印
	//for(int i=0;i<10;i++)
	//{
	//	cout<<vec[i]<<" ";
	//}
	//cout << endl;

	//3.算法函数打印
	//::for_each(vec.begin(),vec.end(),&show);

	//cout<<"size:"<<vec.size()<<"  "<<"capacity:"<<vec.capacity()<<endl;//空间大小 容量大小
	
	vec.push_back(1);
	vec.push_back(2);
	vec.push_back(3);
	vec.push_back(4);

	//插入
	//vector<int>::iterator ite = ::find(vec.begin(),vec.end(),3);//指定位置插入
	//vec.insert(ite,66);
	//::for_each(vec.begin(),vec.end(),&show);

	//删除
	//vector<int>::iterator itePos = ::find(vec.begin(),vec.end(),3);//指定位置插入
	//vec.erase(itePos);
	//::for_each(vec.begin(),vec.end(),&show);

	//清空
	vec.clear();
	::for_each(vec.begin(),vec.end(),&show);


	return 0;
}
