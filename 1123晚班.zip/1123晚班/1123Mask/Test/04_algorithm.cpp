#include<iostream>
#include<vector>
#include<algorithm>
#include<time.h>
using namespace std;

void show(int a)
{
	cout<< a <<" ";
}

bool Rule(int a,int b)
{
	return a>b;
}

int main()
{
	srand((unsigned int)time(0));
	vector<int> vec(10);
	for(int i=0;i<10;i++)
	{
		vec[i] = i;
	}

	::for_each(vec.begin(),vec.end(),&show);
	cout<<endl;
	
	// 随机排列
	::random_shuffle(vec.begin(),vec.end());
	::for_each(vec.begin(),vec.end(),&show);
	cout<<endl;

	// 排序  底层带有堆排 快排 插入排序
	::sort(vec.begin(),vec.end(),&Rule);
	::for_each(vec.begin(),vec.end(),&show);
	cout<<endl;

	// 翻转
	::reverse(vec.begin(),vec.end());
	::for_each(vec.begin(),vec.end(),&show);
	cout<<endl;

	// 统计个数
	cout << ::count(vec.begin(),vec.end(),2)<<endl;
	return 0;
}
