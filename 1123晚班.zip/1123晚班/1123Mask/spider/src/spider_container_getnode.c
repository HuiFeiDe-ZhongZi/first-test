#include<SPIDER.h>


int spider_container_getnode(container_t *,url_t *)
{
	if(ct->cur == 0)
	{
		return -1;
	}

	*node = ct->queue_node[ct->rear];
	--ct->cur;
	ct->rear = (ct->rear + 1) % ct->max;
	return 0;
}

