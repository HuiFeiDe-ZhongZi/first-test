#include<SPIDER.h>


//<h1>大标题</h1>
//<meta name="description" content="词条描述">
//<a href="/item/链接地址>词条名</a> 通过表达式匹配到词条链接，而后提取,在拼接前缀
//https://baike.baidu.con/item/链接地址

int spider_analytical_html(url_t * node,container_t * u_ct,container_t * p_ct)
{
	int fd = open(node.fileName,O_RDWR);
	int fsize = lseek(fd,0,SEEK_END); // 获取大小
	char *string = mmap(NULL,fsize,PROT_READ,MAP_PRIVATE,fd,0);
	close(fd);

	char *jstring = string;

	regex_t hreg,dreg,areg;

	url_t tmp;

	regmatch_t hmatch[2];
	regmatch_t dmatch[2];
	regmatch_t amatch[2];

	char h1[1024];
	char desc[8192];
	char link[4096];
	bzero(h1,1024);
	bzero(desc,8192);
	bzero(link,4096);

	regcomp(&hreg,"<h1 >\\([^<]\\+\\?\\)</h1>)",0);
	regcomp(&dreg,"<meta name=\"descroption\" content=\"\\([^\"]\\+\\?\\)\">",0);
	regcomp(&areg,"<a[^>]\\+\\?href=\"\\(/item/[^\"]\\+\\?\\)\"[^>]\\+\\?>[^<]\\+\\?</a>",0);
	
