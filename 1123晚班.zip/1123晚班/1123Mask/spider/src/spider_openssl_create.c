#include<SPIDER.h>


ssl_t * spider_openssl_create(int)
{

	ssl_t * ssl = (ssl_t *)malloc(sizeof(ssl_t));

	SSL_load_error_strings();
	SSL_library_init();
	OpenSSL_add_ssl_algorithms();

	// 认证上下文
	ssl->sslctx = SSL_CTX_new(SSLv23_method());

	ssl->sslsocket = SSL_new(ssl->sslctx);

	SSL_set_fd(ssl->sslsocket,webfd);

	SSL_connect(ssl->)
