#include<SOCKET.h>




//http://img.pconline.com.cn/images/upload/upc/tx/photoblog/1811/23/c5/120664311_1542959809703_mthumb.jpg

typedef struct
{
	char origin_url[4096]; //存储原始url链接
	char domain[1024]; // 域名
	char path[1024]; // 存储路劲
	char fileName[1024]; // 文件名
	char IP[16]; 
	int PORT;
	int HTYPE; // 0:HTTP 1:HTTPS
}url_t;

typedef struct
{
	SSL * sslsocket;
	SSL_CTX * sslctx;
}ssl_t;

typedef struct
{
	url_t * queue_node;
	int front;
	int rear;
	int max;
	int cur;
}container_t;


int spider_net_init(); // 网络初始化,返回socked

int spider_analytical_url(url_t *); // 传入只附带原始地址的url_t,传出解析后的

int spider_connect_webserver(int,url_t); // 完成tcp链接

int spider_create_request(char *,url_t);

int spider_request_response(int,char*,url_t *,ssl_t *); // 参数为响应头，查找并返回响应头中的响应状态码<int>

int spider_get_statuscode(const char*); // 下载模块，发送请求，接收并处理响应，如果ssl为null表示http交互方式,否则https交互方式

ssl_t * spider_openssl_create(int); // openssl 安全认证过程

container_t *spider_container_create(int); // 容器创建初始化

int spider_remove_duplication(container_t *,container_t *,const char*); // URL去重效验并添加到容器中,成功添加返回0，重复则失败返回-1

int spider_container_setnode(container_t *,url_t *); // 容器添加节点

int spider_container_getnode(container_t *,url_t *); // 从容器中获取

int spider_analytical_html(url_t *,container_t *,container_t *);  // 链接解析及内容解析

int spider_save_data(const char *name,const char *desc,const char *url); // 持久化模块，将解析出的关键要素，以固定格式存储在文件中

int spider_url_controler(const char *alpha_url); // 爬虫控制器，抓取过程

