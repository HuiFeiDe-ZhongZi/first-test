//#include<pthread_pool.h>



//int thread_pool_destroy(thread_pool_t * p) //释放销毁线程池资源
//{
	//	free(p->customer_tids);
	//free(p->manager_tid);
	//free(p->busines_queue);
	//pthread_mutex_destroy(&p->thread_lock);
	//pthread_cond_destroy(&p->not_full);
	//pthread_cond_destroy(&p->not_empty);
	//free(p);
	//return 0;
//}

