#include"comment.h"

int main()
{
	printf("%d\n",add(3,9));
	printf("%d\n",sub(18,9));

	return 0;
}
