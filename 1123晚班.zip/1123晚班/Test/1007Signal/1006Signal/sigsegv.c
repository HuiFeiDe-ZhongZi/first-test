#include<stdio.h>


int main()
{
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");
	printf("ahhhahah\n");

	char *ptr = "ksdjf";
	ptr[0] = 'A';

	return 0;
}
