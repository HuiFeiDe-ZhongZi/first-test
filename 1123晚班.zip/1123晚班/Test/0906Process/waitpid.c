#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>


void sys_jobs()
{
	printf("Ecec System Task....\n");
}

int main(void)
{
	pid_t pid;
	pid = fork();

	if(pid > 0)
	{
		//父进程工作区
		pid_t wpid;
		printf("Parent pid  [%d] Runing...\n",getpid());

		while((wpid = waitpid(-1,NULL,WNOHANG))!=-1)
		{
			printf("Prent Check zomble\n");
			if(wpid > 0)
				printf("[Prent wait [%d]\n",wpid);
			else
			{
				sys_jobs();
				sleep(1);
			}
		}
	}
	else if(pid == 0)
	{
		//子进程工作区
		printf("Child ppid [%d] Running..\n",getpid());
		sleep(5);

		printf("Child pid  exit...\n");
		exit(0);
	}
	else 
	{
		//错误处理
		perror("Fork Call Failed");
		exit(0);
	}

	return 0;
}
