#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>

int main(void)
{
	pid_t pid;
	pid = fork();
	int status;	
	if(pid > 0)
	{
		//父进程工作区
		pid_t wpid;
		printf("Parent pid  [%d] Runing...\n",getpid());
		wpid = wait(&status);
		if(wpid>0)
		{

			printf("[Prent wait [%d]\n",wpid);
			if(WIFEXITED(status))
			{
				printf("wait success child exitcode %d\n",WEXITSTATUS(status));
			}
			if(WIFSIGNALED(status))
			{
				printf("wait success kill child signal %d\n",WTERMSIG(status));
				
			}
		}
	}
	else if(pid == 0)
	{
		//子进程工作区
		printf("Child ppid [%d] Running..\n",getpid());
		//sleep(5);  正常退出
		while(1);  // kill杀死进程退出
		printf("Child pid  exit...\n");
		exit(20);
	}
	else 
	{
		//错误处理
		perror("Fork Call Failed");
		exit(0);
	}
	
	return 0;
}
