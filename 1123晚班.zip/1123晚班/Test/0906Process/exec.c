/*  子进程重载功能  mcpy */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

int eat()
{
	printf("Call Eat jobs...\n");
	return 0;
}

int main()
{
	pid_t pid;
	pid = fork();
	if(pid > 0)
	{
		printf("parent sleeping..\n");
		while(1)
			sleep(1);
	}
	else if(pid == 0)
	{
		eat();
		//重载firefox
		//execl("/usr/bin/firefox","firefox","www.baidu.com",NULL);
		execl("/home/wushuai/1123晚班/0906Process/mycp","mycp","a.jpg","1.jpg",NULL);
		exit(0);
	}


	return 0;
}

//1.默认情况因为继承原因，子进程与父进程
