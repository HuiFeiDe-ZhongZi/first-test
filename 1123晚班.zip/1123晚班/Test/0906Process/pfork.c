#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

/*  多进程模型代码 */

int main()
{
	int pflags = 0;
	pid_t  pid;


	pid=fork();//fork只有父进程可以执行，子进程不允许

	if(pid > 0)
	{
		printf("Parent Pid %d Runing..\n",getpid());
		while(1)
			sleep(1);
	}
	else if(pid == 0)
	{
		printf("Child Pid %d Runing..\n",getpid());
		pid = fork();
		if(pid == 0)
			printf("CChild Pid %d Runing..\n",getpid());
		while(1)
			sleep(1);
	}
	else
	{
		perror("FORK CALL FAILED");
		exit(0);
	}

	return 0;

}

