#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>


int main(void)
{
	pid_t pid;
	pid = fork();
	
	if(pid > 0)
	{
		//父进程工作区
		printf("Parent pid  [%d]  gid [%d] sid [%d] Runing...\n",getpid(),getpgrp(),getsid(getpid()));
		
	}
	else if(pid == 0)
	{

		printf("Def child pid  [%d]  gid [%d] sid [%d] Runing...\n",getpid(),getpgrp(),getsid(getpid()));
		setsid();
		printf("setsid pid  [%d]  gid [%d] sid [%d] Runing...\n",getpid(),getpgrp(),getsid(getpid()));
		while(1);
		//exit(0);//工作执行完成 结束进程 不允许踏出工作区
	}
	else 
	{
		//错误处理
		perror("Fork Call Failed");
		exit(0);
	}

	while(1);
		sleep(1);
	//printf("other jobs..\n");
	return 0;
}
