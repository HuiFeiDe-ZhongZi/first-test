#include<stdio.h>

int main()
{
	char * str="skdfjks";
	str[0]='T';
	printf("%s",str);
	return 0;
}
