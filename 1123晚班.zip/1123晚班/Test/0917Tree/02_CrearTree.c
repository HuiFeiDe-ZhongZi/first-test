#include<stdio.h>
#include<stdlib.h>

typedef struct tree
{
	int nValue;
	struct tree *pLeft;
	struct tree *pRight;
}BinaryTree;


void CreateTree(BinaryTree **pTree)
{
	int nNum;
	scanf("%d",&nNum);

	if(nNum==0)return;
	//创建节点
	*pTree=(BinaryTree*)malloc(sizeof(BinaryTree));
	(*pTree)->nValue=nNum;
	(*pTree)->pLeft=NULL;
	(*pTree)->pRight=NULL;
	
	//左
	CreateTree(&((*pTree)->pLeft));
	//右
	CreateTree(&((*pTree)->pRight));
}

void Pre(BinaryTree *pTree)
{

	if(pTree==NULL)return;
	//根
	printf("%d ",pTree->nValue);
	//左
	Pre(pTree->pLeft);
	//右
	Pre(pTree->pRight);
}

void Mid(BinaryTree *pTree)
{

	if(pTree==NULL)return;
	//左
	Mid(pTree->pLeft);
	//根
	printf("%d ",pTree->nValue);
	//右
	Mid(pTree->pRight);
}

void Last(BinaryTree *pTree)
{

	if(pTree==NULL)return;
	//左
	Last(pTree->pLeft);
	//右
	Last(pTree->pRight);
	//根
	printf("%d ",pTree->nValue);
}

BinaryTree *ArrToTree(int arr[],int nLen)
{
	if(arr==NULL||nLen<=0)return NULL;

	//申请结构体数组
	BinaryTree *pTree=(BinaryTree*)malloc(sizeof(BinaryTree)*nLen);
	
	//赋值
	int i;
	for(i=0;i<nLen;i++)
	{
		pTree[i].nValue=arr[i];
		pTree[i].pLeft=NULL;
		pTree[i].pRight=NULL;
	}

	//左右关系
	for(i=0;i<=nLen/2-1;i++)
	{
		if(2*i+1<=nLen-1)
		{
			pTree[i].pLeft=&pTree[2*i+1];
		}
		if(2*i+2<=nLen-1)
		{
			pTree[i].pRight=&pTree[2*i+2];
		}
	}
	return pTree;
}

int main()
{
	BinaryTree *pTree=NULL;
	//CreateTree(&pTree);
	int arr[]={1,2,3,4,5,6,7,8};
	pTree=ArrToTree(arr,sizeof(arr)/sizeof(arr[0]));	
	Pre(pTree);
	printf("\n");

	Mid(pTree);
	printf("\n");

	Last(pTree);
	printf("\n");
	return 0;
}
