#include<stdio.h>
#include<stdlib.h>

typedef struct tree
{
	int nValue;
	struct tree *pFather;
	struct tree *pLeft;
	struct tree *pRight;
}BinaryTree;

BinaryTree *CreateBinaryTree()
{
	//根
	BinaryTree *pTree=(BinaryTree*)malloc(sizeof(BinaryTree));
	pTree->nValue=1;
	pTree->pFather=NULL;
	//根的左
	pTree->pLeft=(BinaryTree*)malloc(sizeof(BinaryTree));
	pTree->pLeft->nValue=2;
	pTree->pLeft->pFather=pTree;
	//左的左
	pTree->pLeft->pLeft=(BinaryTree*)malloc(sizeof(BinaryTree));
	pTree->pLeft->pLeft->nValue=4;
	pTree->pLeft->pLeft->pFather=pTree->pLeft;
	pTree->pLeft->pLeft->pLeft=NULL;
	pTree->pLeft->pLeft->pRight=NULL;
	//左的右
	pTree->pLeft->pRight=(BinaryTree*)malloc(sizeof(BinaryTree));
	pTree->pLeft->pRight->nValue=5;
	pTree->pLeft->pRight->pFather=pTree->pLeft;
	pTree->pLeft->pRight->pLeft=NULL;
	pTree->pLeft->pRight->pRight=NULL;
	//根的右
	pTree->pRight=(BinaryTree*)malloc(sizeof(BinaryTree));
	pTree->pRight->nValue=3;
	pTree->pRight->pFather=pTree;
	pTree->pRight->pLeft=NULL;
	pTree->pRight->pRight=NULL;
	
	return pTree;
}

void Pre(BinaryTree *pTree)
{

	if(pTree==NULL)return;
	//根
	printf("%d ",pTree->nValue);
	//左
	Pre(pTree->pLeft);
	//右
	Pre(pTree->pRight);
}

void Mid(BinaryTree *pTree)
{

	if(pTree==NULL)return;
	//左
	Mid(pTree->pLeft);
	//根
	printf("%d ",pTree->nValue);
	//右
	Mid(pTree->pRight);
}

void Last(BinaryTree *pTree)
{

	if(pTree==NULL)return;
	//左
	Last(pTree->pLeft);
	//右
	Last(pTree->pRight);
	//根
	printf("%d ",pTree->nValue);
}

void  RightRotate(BinaryTree **pTree)
{
	if(*pTree==NULL||(*pTree)->pLeft==NULL)return;

	BinaryTree *pNode=*pTree;//A
	BinaryTree *pMark=pNode->pLeft;//B
	
	//三个孩子关系
	pNode->pLeft = pMark->pRight;//E是A的左
	pMark->pRight=pNode;//A是B的右

	//根  B是X的孩子
	if(pNode->pFather==NULL)
	{
		*pTree=pMark;
	}
	else
	{
		if(pNode ==pNode->pFather->pLeft)
		{
			pNode->pFather->pLeft=pMark;
		}
		else
		{
			pNode->pFather->pRight=pMark;
		}
	}
	
	//三个父亲关系
	if(pNode->pLeft != NULL)
	{
		pNode->pLeft->pFather=pNode;//E的父亲是A
	}
	pMark->pFather=pNode->pFather;//B的父亲是X
	pNode->pFather=pMark;//A的父亲是B

}
void  LeftRotate(BinaryTree **pTree)
{
	if(*pTree==NULL||(*pTree)->pRight==NULL)return;

	BinaryTree *pNode=*pTree;//A
	BinaryTree *pMark=pNode->pRight;//B
	
	pNode->pRight = pMark->pLeft;
	pMark->pLeft=pNode;

	if(pNode->pFather==NULL)
	{
		*pTree=pMark;
	}
	else
	{
		if(pNode ==pNode->pFather->pLeft)
		{
			pNode->pFather->pLeft=pMark;
		}
		else
		{
			pNode->pFather->pRight=pMark;
		}
	}
	
	if(pNode->pRight != NULL)
	{ 
		pNode->pRight->pFather=pNode;
	}
	pMark->pFather=pNode->pFather;
	pNode->pFather=pMark;

}
int main()
{
	BinaryTree *pTree=CreateBinaryTree();
	Pre(pTree);
	printf("\n");
	
	RightRotate(&pTree);
	Pre(pTree);
	printf("\n");

	LeftRotate(&pTree);
	Pre(pTree);
	printf("\n");
	
	//Mid(pTree);
	//printf("\n");

	//Last(pTree);
	//printf("\n");
	return 0;
}
