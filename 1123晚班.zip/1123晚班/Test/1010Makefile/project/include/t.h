#include<stdio.h>
#include<unistd.h>

int add(int,int);
int sub(int,int);
int mul(int,int);
int des(int,int);
