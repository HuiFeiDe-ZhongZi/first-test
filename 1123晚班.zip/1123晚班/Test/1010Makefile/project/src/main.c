#include<t.h>

int main()
{
	printf("result=%d\n",add(123,456));
	return 0;
}
