
#include<t.h>

int mul(int code1,int code2)
{
	return code1 * code2;
}
