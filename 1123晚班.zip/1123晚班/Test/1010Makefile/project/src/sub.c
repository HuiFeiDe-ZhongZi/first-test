#include<t.h>

int sub(int code1,int code2)
{
	return code1 - code2;
}
