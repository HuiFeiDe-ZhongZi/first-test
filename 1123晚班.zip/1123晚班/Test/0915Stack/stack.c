#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int nValue;
	struct node *pNext;
}Mystack;

void Push(Mystack **pTop,int nNum)
{
	Mystack *pTemp=NULL;
	pTemp=(Mystack*)malloc(sizeof(Mystack));
	pTemp->nValue=nNum;
	pTemp->pNext=*pTop;
	*pTop=pTemp;
}

int Pop(Mystack **pTop)
{
	if(*pTop==NULL)return -1;
	Mystack *pDel=*pTop;
	int nNum=pDel->nValue;

	*pTop= (*pTop)->pNext;
	free(pDel);
	pDel=NULL;
	return nNum;
}
int main()
{
	Mystack *pTop=NULL;
	Push(&pTop,1);
	Push(&pTop,2);
	Push(&pTop,3);
	Push(&pTop,4);

	printf("%d\n",Pop(&pTop));
	printf("%d\n",Pop(&pTop));
	printf("%d\n",Pop(&pTop));
	printf("%d\n",Pop(&pTop));


	return 0;
}

