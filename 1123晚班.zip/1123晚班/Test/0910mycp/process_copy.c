#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/wait.h>
#include<fcntl.h>

int block_cur(const char * srcfile,int prono)
{
	int filesize;
	int fd;
	fd=open(srcfile,O_RDONLY);
	filesize=lseek(fd,0,SEEK_END);

	if(filesize % prono==0)
		return filesize / prono;
	else
		return filesize / prono + 1;
}

int process_create(const char *srcfile,const char *desfile,int prono,int blocksize)
{
	pid_t pid;
	int flags;
	for(flags = 0;flags < prono;flags ++)
	{
		pid=fork();
		if(pid == 0)
			break;
	}

	if(pid > 0)
	{
		//处理僵尸进程
		pid_t wpid;
		printf("parent start...\n");
		while((wpid = wait(NULL))>0)
		{
			printf("parent wait child zpid [%d]\n",wpid);
		}
	}
	else if(pid == 0)
	{
		int pos;
		pos = flags * blocksize;
		char ssize[1024];
		char spos[1024];
		bzero(ssize,sizeof(ssize));
		bzero(spos,sizeof(spos));
		sprintf(ssize,"%d",blocksize);
		sprintf(spos,"%d",pos);
		execl("/home/wushuai/1123晚班/0910mycp/copy","copy",srcfile,desfile,spos,ssize,NULL);

	}
	else
	{
		perror("error exit ...\n");
		exit(0);
	}

}
int main(int argc,char ** argv)
{
	int prono; 

	if(argc < 3)
	{
		printf("please press src des and prono...\n");
		exit(0);
	}

	if(argv[3]== 0)
		prono = 5;
	else
		prono = atoi(argv[3]);
	if(prono <=0 ||prono >100)
	{
		printf("Enter ProcessNo Error!\n");
		exit(0);
	}

	if((access(argv[1],F_OK))!=0)
	{
		printf("srcfile no exit...\n");
		exit(0);
	}

	int filesize = block_cur(argv[1],prono);
	printf("filesize ...[%d]\n",filesize);
	process_create(argv[1],argv[2],prono,filesize);

	return 0;
}
