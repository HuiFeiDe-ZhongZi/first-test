#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(int argc,char **argv)
{
	int blocksize = atoi(argv[3]);
	int pos = atoi(argv[4]);
	char buffer[blocksize];
	bzero(buffer,sizeof(buffer));
	int recv_size;
	int srf=open(argv[1],O_RDONLY);
	int dif=open(argv[2],O_WRONLY|O_CREAT,0775);

	//偏移
	lseek(srf,pos,SEEK_SET);
	lseek(dif,pos,SEEK_SET);
	
	recv_size=read(srf,buffer,sizeof(buffer));
	write(dif,buffer,sizeof(buffer));
	bzero(buffer,sizeof(buffer));
	printf("child pid [%d] start [%d] end [%d] blocksize [%d]\n",getpid(),atoi(argv[4]),atoi(argv[4])+atoi(argv[3]),atoi(argv[3]));
	close(srf);
	close(dif);
	return 0;

}
