#include<stdio.h>
#include<stdlib.h>

typedef struct data
{
	int nValue;
	struct data *pNext;
}Data;

typedef struct queue
{
	int count;
	Data *pHead;
	Data *pTail;
}Queue;


void q_Init(Queue **pQueue)
{
	*pQueue=(Queue*)malloc(sizeof(Queue));
	(*pQueue)->count=0;
	(*pQueue)->pHead=NULL;
	(*pQueue)->pTail=NULL;
}

Queue *q_Push(Queue *pQueue,int nNum)
{
	if(pQueue==NULL)exit(1);
	
	Data *pTemp=(Data*)malloc(sizeof(Data));
	pTemp->nValue=nNum;
	pTemp->pNext=NULL;
	pQueue->count++;

	if(pQueue->pHead==NULL)
	{
			pQueue->pHead=pTemp;
	}
	else
	{
		pQueue->pTail->pNext=pTemp;
	}
	pQueue->pTail=pTemp;
}
	
int q_Pop(Queue *pQueue)
{
	if(pQueue==NULL)exit(1);
	if(pQueue->count==0)return -1;

	Data* pDel=pQueue->pHead;
	int num=pQueue->pHead->nValue;
	pQueue->pHead=pQueue->pHead->pNext;
	free(pDel);
	pDel=NULL;

	pQueue->count--;

	return num;
}

int q_Isempty(Queue *pQueue)
{
	if(pQueue==NULL)exit(1);

	return pQueue->count==0? 1 :0;
}

int main()
{
	Queue *pQueue = NULL;
	q_Init(&pQueue);
	q_Push(pQueue,1);
	q_Push(pQueue,2);
	q_Push(pQueue,3);
	q_Push(pQueue,4);

	printf("%d\n",q_Pop(pQueue));
	printf("%d\n",q_Pop(pQueue));
	printf("%d\n",q_Pop(pQueue));
	printf("%d\n",q_Pop(pQueue));

	printf("-------%d---\n",q_Isempty(pQueue));	

	return 0;
}
