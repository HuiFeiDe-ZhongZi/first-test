#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int nValue;
	struct node *pNext;
}Node;

typedef struct Stack
{
	int nCount;
	Node *pTop;
}Mystack;

void s_Init(Mystack **pStack)
{
	*pStack=(Mystack*)malloc(sizeof(Mystack));
	(*pStack)->nCount=0;
	(*pStack)->pTop=NULL;
}

void s_Push(Mystack *pStack,int nNum)
{
	if(pStack==NULL)exit(1);
	Node *pTemp=(Node*)malloc(sizeof(Node));
	pTemp->nValue=nNum;
	pTemp->pNext=pStack->pTop;
	pStack->pTop=pTemp;
	pStack->nCount++;
}

int s_Pop(Mystack *pStack)
{
	if(pStack==NULL)exit(1);
	if(pStack->nCount==0)return -1;
	Node *pDel=pStack->pTop;
	int nNum=pDel->nValue;

	pStack->pTop= pStack->pTop->pNext;
	free(pDel);
	pDel=NULL;
	pStack->nCount--;
	return nNum;
}

void s_clear(Mystack *pStack)
{
	if(pStack==NULL)exit(1);
	while(pStack->nCount!=0)
	{
		s_Pop(pStack);
	}
}

void s_Destory(Mystack **pStack)
{
	s_clear(*pStack);

	free(pStack);
	*pStack=NULL;
}

Node *s_GetTop(Mystack *pStack)
{
	if(pStack==NULL)exit(1);
	return pStack->pTop;
}

int s_IsEmpty(Mystack *pStack)
{
	if(pStack==NULL)exit(1);
	return pStack->nCount==0 ?1:0;
}

typedef struct queue
{
	int nCount;
	Mystack *pStack1;
	Mystack *pStack2;
}Queue;

void q_Init(Queue **pQueue)
{
	*pQueue=(Queue*)malloc(sizeof(Queue));
	(*pQueue)->nCount=0;
	s_Init(&((*pQueue)->pStack1));
	s_Init(&((*pQueue)->pStack2));
}

void q_Push(Queue *pQueue,int nNum)
{
	if(pQueue==NULL||pQueue->pStack2==NULL||pQueue->pStack1==NULL)exit(1);

	//栈1入队
	//栈2非空 将元素放回栈1
	while(pQueue->pStack2->nCount!=0)
	{
		s_Push(pQueue->pStack1,s_Pop(pQueue->pStack2));
	}
	//新元素入栈一
	s_Push(pQueue->pStack1,nNum);
	pQueue->nCount++;
}

int q_Pop(Queue *pQueue)
{
	if(pQueue==NULL||pQueue->pStack2==NULL||pQueue->pStack1==NULL)exit(1);
	if(pQueue->nCount==0)return -1;
	
	//栈2出队
	//栈1非空 元素入栈2
	while(pQueue->pStack1->nCount!=0)
	{
		s_Push(pQueue->pStack2,s_Pop(pQueue->pStack1));
	}
	
	int num=s_Pop(pQueue->pStack2);
	pQueue->nCount--;
	return num;
}




int main()
{
	Queue *pQueue=NULL;

	q_Init(&pQueue);
	q_Push(pQueue,1);
	q_Push(pQueue,2);
	q_Push(pQueue,3);
	q_Push(pQueue,4);

	printf("%d\n",q_Pop(pQueue));
	printf("%d\n",q_Pop(pQueue));
	printf("%d\n",q_Pop(pQueue));
	printf("%d\n",q_Pop(pQueue));


	return 0;
}

