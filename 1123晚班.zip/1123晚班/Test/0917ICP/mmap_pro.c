#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/mman.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(void)
{
	//1.打开映射文件
	int fd = open("mmap_file_01",O_RDWR);
	//2.获取文件大小
	int fsize=lseek(fd,0,SEEK_END);
	//3.对文件进行共享映射，申请映射内存
	int *ptr = NULL;
	
	ptr = mmap(NULL,fsize,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);

	close(fd);//关闭无用描述符

	ptr[0]=0x66666666;
	//4.使用完毕，释放映射
	munmap(ptr,fsize);

	return 0;
}
