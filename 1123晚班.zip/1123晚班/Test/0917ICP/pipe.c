#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>

#define MESSAGE "hi Son,can u hear me ?"

int main()
{
	pid_t pid;
	/*管道创建要在fork前完成，避免重复创建*/
	int fds[2];
	pipe(fds);//管道创建
	pid=fork();
	/*使用管道时要确定通信方向：父写子读（确定方向后，将不用的fd关闭)*/
	if(pid>0)
	{
		close(fds[0]);
		printf("Parent pro pid [%d] Send Message..\n",getpid());
		write(fds[1],MESSAGE,sizeof(MESSAGE));
		close(fds[1]);//用完了将此描述符关闭
		printf("Parent Done.\n");
		while(1)
			sleep(1);
	}
	else if(pid==0)
	{
		int rsize;
		close(fds[1]);
		char Buffer[100];
		bzero(Buffer,sizeof(Buffer));
		printf("Child pro pid [%d] Recv Message..\n",getpid());
		rsize=read(fds[0],Buffer,sizeof(Buffer));
		close(fds[0]);
		printf("Child read Message [%s].\n",Buffer);
		while(1)
			sleep(1);
	}
	else
	{
		perror("fork call failed");
		exit(0);
	}



	return 0;
}
