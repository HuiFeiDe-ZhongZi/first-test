#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdlib.h>
#include<error.h>
#include<sys/ioctl.h>


int main()
{
	struct winsize size;
	if(isatty(STDOUT_FILENO) == 0)
		exit(1);
	if(ioctl(STDOUT_FILENO,TIOCGWINSZ,&size)<0)
	{
		perror("ioctl TIOCGWINSZ error");
		exit(1);
	}
	printf("%d rows,%d columns\n",size.ws_row,size.ws_col);

	return 0;
}
