#include<stdio.h>
#include<unistd.h>

int main()
{

	int a=0;


	alarm(1);

	while(1)
	{
		printf("++a %d\t",++a);
	}
	return 0;
}
