#include<stdio.h>
#include<signal.h>
#include<stdlib.h>

int main(int argc,char *argv[])
{
	if(argc < 3)
	{
		printf("ERROR:Please press Signumber and Pid！\n");
		return -1;
	}
	

	kill(atoi(argv[2]),atoi(argv[1]));
	return 0;
}


