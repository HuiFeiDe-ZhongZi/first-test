#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

void Daemon_job()
{
	int fd;
	if((fd = open("time.log",O_RDWR))==-1)
		perror("Daemon_job function error,open call failed");
	time_t tp;
	char tbuffer[1024];
	bzero(tbuffer,sizeof(tbuffer));
	while(1)
	{
		tp = time(NULL);
		ctime_r(&tp,tbuffer);
		write(fd,tbuffer,strlen(tbuffer));
		bzero(tbuffer,sizeof(tbuffer));
		sleep(3);
	}
}


//path为守护进程的工作路径
void Create_daemon(const char *path)
{
	pid_t pid;
	pid = fork();

	if(pid > 0)
	{
		exit(0);
	}
	else if(pid == 0)
	{
		//创建错误日志文件
		int fd =open("error.log",O_RDWR|O_CREAT|O_APPEND,0664);//O_APPEND以追加方式 往后放
		setsid();
		close(STDIN_FILENO);
		close(STDOUT_FILENO);
		//输出重定向
		dup2(fd,STDERR_FILENO);
		chdir(path);
		umask(0002);
		Daemon_job();
		//守护进程的退出处理
		//释放资源
		//清理缓存
	}
	else
	{
		perror("Error fork call faild");
		exit(-1);
	}
}

int main()
{
	Create_daemon("./");

	return 0;
}
