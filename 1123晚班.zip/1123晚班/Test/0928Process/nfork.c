#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	pid_t pid;
	pid = fork();

	if(pid >0)
	{
		printf("parent ....\n");
		exit(0);
	}
	else if(pid == 0)
	{
		while(1)
		{
			printf("child process..\n");
			sleep(1);
		}
	}
	else
	{
		perror("perror..\n");
		exit(1);
	}


	return 0;
}
