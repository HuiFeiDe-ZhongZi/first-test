#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

//错误提示
void err(const char *str)
{
	perror(str);
	exit(0);
}

typedef struct cp
{
	char *srcfile_add;
	char *desfile_add;
	int pthread_num;
	int block_size;
}mycp;


void block_cur(const char *srcfile,int num)
{
	int filesize;
	int fd;
	fd = open(srcfile,O_RDONLY);
	filesize = lseek(fd,0,SEEK_END);
	if(filesize % num == 0)
		return filesize / num;
	else
		return filesize / num + 1;
}

void *tjob(void *arg)
{


int pthread_create(const char *srcfile,const char *desfile,int num,int blocksize)
{
	mycp *im = NULL;

	pthread_t tid[num];
	int i;
	for(i = 0;i < num;i++)
	{
		im->srcfile_add =  
		im->desfile_add = desfile;
		im->pthread_num = num;
		im->blocksize =blocksize;

		pthread_create(&tid[flags],NULL,&tjob,NULL);
	}
}

int main(int argc,char **argv)
{
	int num;  //线程数量
	//参数校验
	if(argc < 3)
	{
		printf("Please add src dec ...\n");
		exit(0);
	}

	if(argv[3] == 0)
		num = 5;
	else
		num = atoi(argv[3]);

	if(num <= 0|| num>=300)
		err("pthread nums error!");
	if((access(argv[1],F_OK))!=0)
		err("srcfile not exit..!");
	
	int blocksize = block_cur(argv[1],num);
	pthread_create(argv[1],argv[2],num,blocksize);
	
	return 0;
}
	

