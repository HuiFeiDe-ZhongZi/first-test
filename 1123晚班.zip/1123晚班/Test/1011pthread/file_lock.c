#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>

#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

//max_thread.c 对特定文件进行文件锁设置


int main()
{
	struct flock lock;

	int fd = open("max_thread.c",O_RDWR);

	//获取文件锁属性，查看是否已被锁?
	

	lock.l_type = F_WRLCK;
	lock.l_whence = SEEK_SET;
	lock.l_start = 0;
	lock.l_len = 0; //锁整个文件
	printf("pro 2 pid %d try set wrlock..\n",getpid());
	fcntl(fd,F_SETLKW,&lock); 
	printf("pro 2 pid %d set wrlock success..\n",getpid());
	lock.l_type = F_UNLCK; //解锁
	fcntl(fd,F_SETLK,&lock);
	printf("pro 2 pid %d unlock..\n",getpid());

	return 0;
}


