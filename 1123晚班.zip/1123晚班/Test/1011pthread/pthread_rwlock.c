#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<pthread.h>


int code;
pthread_rwlock_t rwlock;


void *write_thread(void *arg)
{
	while(1)
	{
		pthread_rwlock_wrlock(&rwlock);
		printf("write thread <0x%x> ++code <%d>\n",(unsigned int)pthread_self(),++code);
		pthread_rwlock_unlock(&rwlock);
		usleep(100000);
	}
}

void *read_thread(void *arg)
{
	while(1)
	{
		pthread_rwlock_wrlock(&rwlock);
		printf("read thread <0x%x> code <%d>\n",(unsigned int)pthread_self(),code);
		pthread_rwlock_unlock(&rwlock);
		usleep(100000);
	}
}

int main()
{
	pthread_t tid[8];

	int i = 0;
	pthread_rwlock_init(&rwlock,NULL);
	for(i;i<3;i++)
	{
		pthread_create(&tid[i],NULL,write_thread,NULL);
	}
	for(i;i<8;i++)
	{
		pthread_create(&tid[i],NULL,read_thread,NULL);
	}

	while(i--)
	{
		pthread_join(tid[i],NULL);
	}
	pthread_rwlock_destroy(&rwlock);
	return 0;
}

